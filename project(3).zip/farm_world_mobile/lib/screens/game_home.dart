import 'package:flutter/material.dart';

class GameHome extends StatefulWidget {
  const GameHome({super.key});

  @override
  State<GameHome> createState() => _GameHomeState();
}

class _GameHomeState extends State<GameHome> {
  int _tab = 0;
  int _coins = 12500;
  int _wheat = 24;
  int _corn = 12;
  bool _planted = false;

  void _sellHarvest() {
    if (_wheat == 0 && _corn == 0) {
      _message('لا توجد محاصيل للبيع حالياً');
      return;
    }
    setState(() {
      _coins += _wheat * 35 + _corn * 52;
      _wheat = 0;
      _corn = 0;
    });
    _message('تم بيع المحاصيل وإضافة الأرباح إلى رصيدك');
  }

  void _plant() {
    setState(() => _planted = !_planted);
    _message(_planted ? 'تم تجهيز الحقل للزراعة (نموذج تجريبي)' : 'تم إيقاف تجهيز الحقل');
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _farmPage(),
      _garagePage(),
      _marketPage(),
      _profilePage(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.agriculture, color: Color(0xFF4D8B45)),
          SizedBox(width: 9),
          Text('عالم المزرعة', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        actions: [
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 14),
            child: Chip(
              avatar: const Icon(Icons.monetization_on, color: Color(0xFFE2A52B)),
              label: Text('$_coins'),
              side: BorderSide.none,
              backgroundColor: const Color(0xFFFFF1D2),
            ),
          ),
        ],
      ),
      body: SafeArea(child: AnimatedSwitcher(duration: const Duration(milliseconds: 220), child: pages[_tab])),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.grass_outlined), selectedIcon: Icon(Icons.grass), label: 'مزرعتي'),
          NavigationDestination(icon: Icon(Icons.agriculture_outlined), selectedIcon: Icon(Icons.agriculture), label: 'المرآب'),
          NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'المتجر'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }

  Widget _farmPage() => ListView(
    key: const ValueKey('farm'),
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        height: 190,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFFB8DDA0), Color(0xFF5E9A55), Color(0xFF315E3A)]),
        ),
        child: Stack(children: [
          Positioned(right: 18, top: 18, child: _tag('الموسم الأول')),
          const Positioned(left: 22, bottom: 18, child: Icon(Icons.agriculture, size: 92, color: Colors.white)),
          const Positioned(right: 20, bottom: 22, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('مرحباً بك في مزرعتك', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.bold)),
            SizedBox(height: 5),
            Text('ازرع، احصد، ووسّع أرضك', style: TextStyle(color: Colors.white)),
          ])),
        ]),
      ),
      const SizedBox(height: 18),
      const Text('ملخص المزرعة', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: _statCard('مساحة الأرض', '4 هكتار', Icons.landscape, const Color(0xFFE5F1DE))),
        const SizedBox(width: 10),
        Expanded(child: _statCard('المستوى', '1', Icons.stars, const Color(0xFFFFF0D2))),
        const SizedBox(width: 10),
        Expanded(child: _statCard('العمال', '2', Icons.people, const Color(0xFFE1EDFA))),
      ]),
      const SizedBox(height: 18),
      const Text('حقولك', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      _fieldCard('حقل القمح', 'قمح', 'جاهز للحصاد', Icons.grass, const Color(0xFFD9B45C)),
      _fieldCard('حقل الذرة', 'ذرة', 'ينمو — 65%', Icons.eco, const Color(0xFF70A84F)),
      const SizedBox(height: 18),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: _plant, icon: const Icon(Icons.agriculture), label: Text(_planted ? 'إلغاء تجهيز الحقل' : 'تجهيز الحقل'))),
        const SizedBox(width: 10),
        Expanded(child: FilledButton.icon(onPressed: _sellHarvest, icon: const Icon(Icons.sell), label: const Text('بيع المحاصيل'))),
      ]),
      const SizedBox(height: 10),
      const Text('هذه نسخة تجريبية ببيانات محلية. لم يتم تفعيل الحفظ السحابي أو محاكاة نمو المحاصيل بعد.', style: TextStyle(color: Colors.black54, fontSize: 12)),
    ],
  );

  Widget _garagePage() => ListView(
    key: const ValueKey('garage'),
    padding: const EdgeInsets.all(16),
    children: [
      const Text('مرآب الآلات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('إدارة مركبات مزرعتك ومعدّاتك الزراعية'),
      const SizedBox(height: 18),
      _vehicleCard('جرار المزرعة الأساسي', 'متاح', Icons.agriculture, 'السرعة: 18 كم/س'),
      _vehicleCard('محراث', 'ملحق', Icons.construction, 'عرض العمل: 2 متر'),
      _vehicleCard('آلة حصاد', 'مقفلة', Icons.precision_manufacturing, 'تُفتح عند المستوى 3'),
      const SizedBox(height: 12),
      const Text('نماذج تعريفية فقط؛ قيادة المركبات ثلاثية الأبعاد ستضاف في مرحلة محرك اللعبة.', style: TextStyle(color: Colors.black54, fontSize: 12)),
    ],
  );

  Widget _marketPage() => ListView(
    key: const ValueKey('market'),
    padding: const EdgeInsets.all(16),
    children: [
      const Text('سوق المزرعة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('اشترِ البذور والمستلزمات لتطوير إنتاجك'),
      const SizedBox(height: 18),
      _productCard('بذور القمح', '120 قطعة', Icons.grass, () => _buy(120, 'تم شراء بذور القمح')),
      _productCard('بذور الذرة', '180 قطعة', Icons.eco, () => _buy(180, 'تم شراء بذور الذرة')),
      _productCard('سماد عضوي', '250 قطعة', Icons.compost, () => _buy(250, 'تم شراء السماد')),
      _productCard('وقود الجرار', '90 قطعة', Icons.local_gas_station, () => _buy(90, 'تم شراء الوقود')),
    ],
  );

  void _buy(int price, String success) {
    if (_coins < price) {
      _message('رصيدك غير كافٍ');
      return;
    }
    setState(() => _coins -= price);
    _message(success);
  }

  Widget _profilePage() => ListView(
    key: const ValueKey('profile'),
    padding: const EdgeInsets.all(16),
    children: [
      const CircleAvatar(radius: 42, backgroundColor: Color(0xFFDCEBD5), child: Icon(Icons.person, size: 46, color: Color(0xFF4D8B45))),
      const SizedBox(height: 12),
      const Center(child: Text('مزارع جديد', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold))),
      const Center(child: Text('المستوى 1 • مبتدئ', style: TextStyle(color: Colors.black54))),
      const SizedBox(height: 22),
      _settingTile(Icons.cloud_outlined, 'حالة الحفظ', 'محلي على هذا الجهاز', () {}),
      _settingTile(Icons.group_outlined, 'اللعب الجماعي', 'قريباً — لم يتم ربط الخادم', () => _message('سيتم تفعيل اللعب الجماعي في مرحلة لاحقة')),
      _settingTile(Icons.settings_outlined, 'الإعدادات', 'الصوت واللغة والتحكم', () {}),
      _settingTile(Icons.info_outline, 'حول اللعبة', 'Farm World Mobile • إصدار تجريبي', () {}),
    ],
  );

  Widget _tag(String text) => Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .88), borderRadius: BorderRadius.circular(30)), child: Text(text, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF315E3A))));

  Widget _statCard(String title, String value, IconData icon, Color color) => Card(child: Padding(padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8), child: Column(children: [CircleAvatar(backgroundColor: color, child: Icon(icon, color: const Color(0xFF315E3A))), const SizedBox(height: 8), Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), Text(title, style: const TextStyle(fontSize: 11, color: Colors.black54))])));

  Widget _fieldCard(String title, String crop, String status, IconData icon, Color color) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: color.withValues(alpha: .2), child: Icon(icon, color: color)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('$crop • $status'), trailing: const Icon(Icons.chevron_left)));

  Widget _vehicleCard(String title, String status, IconData icon, String detail) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFFE5F1DE), child: Icon(icon, color: const Color(0xFF4D8B45))), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(detail), trailing: Text(status, style: const TextStyle(color: Color(0xFF4D8B45), fontWeight: FontWeight.bold))));

  Widget _productCard(String title, String price, IconData icon, VoidCallback onBuy) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFFFFF0D2), child: Icon(icon, color: const Color(0xFF9A6B16))), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(price), trailing: FilledButton.tonal(onPressed: onBuy, child: const Text('شراء'))));

  Widget _settingTile(IconData icon, String title, String subtitle, VoidCallback onTap) => Card(child: ListTile(onTap: onTap, leading: Icon(icon, color: const Color(0xFF4D8B45)), title: Text(title), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_left)));
}
