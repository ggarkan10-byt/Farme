import 'dart:math' as math;
import 'package:flutter/material.dart';

/// مشهد إيزومتري تفاعلي شبه ثلاثي الأبعاد (2.5D) مرسوم داخل Flutter.
class FarmWorldScene extends StatelessWidget {
  const FarmWorldScene({
    super.key,
    required this.tractorX,
    required this.tractorY,
    required this.fieldStage,
    required this.zoom,
  });

  final double tractorX;
  final double tractorY;
  final int fieldStage;
  final double zoom;

  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(22),
    child: AspectRatio(
      aspectRatio: 1.18,
      child: ColoredBox(
        color: const Color(0xFFB9D9E9),
        child: CustomPaint(
          painter: _FarmPainter(tractorX, tractorY, fieldStage, zoom),
          child: const SizedBox.expand(),
        ),
      ),
    ),
  );
}

class _FarmPainter extends CustomPainter {
  _FarmPainter(this.tx, this.ty, this.stage, this.zoom);
  final double tx, ty, zoom;
  final int stage;

  Offset iso(double x, double y, Offset c, double s) =>
      Offset(c.dx + (x-y)*s, c.dy + (x+y)*s*.48);

  void polygon(Canvas canvas, List<Offset> points, Color color) {
    final p = Path()..moveTo(points.first.dx, points.first.dy);
    for (final point in points.skip(1)) { p.lineTo(point.dx, point.dy); }
    p.close();
    canvas.drawPath(p, Paint()..color=color);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final s = math.min(size.width/15, size.height/9)*zoom;
    final c = Offset(size.width*.51, size.height*.43);
    canvas.drawRect(Offset.zero & size, Paint()..color=const Color(0xFFB9D9E9));

    final hills = Path()
      ..moveTo(0,size.height*.42)
      ..quadraticBezierTo(size.width*.2,size.height*.15,size.width*.42,size.height*.38)
      ..quadraticBezierTo(size.width*.7,size.height*.12,size.width,size.height*.35)
      ..lineTo(size.width,size.height)..lineTo(0,size.height)..close();
    canvas.drawPath(hills, Paint()..color=const Color(0xFF91B77B));

    final a=iso(0,0,c,s), b=iso(8,0,c,s), d=iso(0,6,c,s), e=iso(8,6,c,s);
    polygon(canvas,[a,b,e,d],const Color(0xFF6F9E55));
    polygon(canvas,[d,e,Offset(e.dx,e.dy+12),Offset(d.dx,d.dy+12)],const Color(0xFF456F3D));

    for (int y=0;y<6;y++) {
      for (int x=0;x<8;x++) {
        final p1=iso(x.toDouble(),y.toDouble(),c,s);
        final p2=iso(x+1.0,y.toDouble(),c,s);
        final p3=iso(x+1.0,y+1.0,c,s);
        final p4=iso(x.toDouble(),y+1.0,c,s);
        final field=x>=2&&x<=5&&y>=2&&y<=4;
        final tile=field
          ? (stage==0?const Color(0xFF9A7046):stage==1?const Color(0xFF6F583B):const Color(0xFF9C8545))
          : ((x+y).isEven?const Color(0xFF78A95C):const Color(0xFF568B49));
        polygon(canvas,[p1,p2,p3,p4],tile);
        final border=Path()..moveTo(p1.dx,p1.dy)..lineTo(p2.dx,p2.dy)..lineTo(p3.dx,p3.dy)..lineTo(p4.dx,p4.dy)..close();
        canvas.drawPath(border,Paint()..color=Colors.white.withValues(alpha:.10)..style=PaintingStyle.stroke..strokeWidth:.7);
        if(field&&stage>0) {
          final m=Offset((p1.dx+p2.dx+p3.dx+p4.dx)/4,(p1.dy+p2.dy+p3.dy+p4.dy)/4);
          final crop=Paint()..color=stage==1?const Color(0xFF6B9B38):const Color(0xFFE6C34F)..strokeWidth=2.2..strokeCap=StrokeCap.round;
          for(int i=-1;i<=1;i++) {
            final x0=m.dx+i*s*.24, y0=m.dy-s*.08;
            canvas.drawLine(Offset(x0,y0),Offset(x0-s*.04,y0-s*.18),crop);
            canvas.drawLine(Offset(x0,y0),Offset(x0+s*.05,y0-s*.15),crop);
          }
        }
      }
    }

    // بيت المزرعة
    final h=iso(1,1,c,s);
    final hr=Rect.fromCenter(center:Offset(h.dx,h.dy-s*.22),width:s*.92,height:s*.56);
    canvas.drawRect(hr,Paint()..color=const Color(0xFFF2E4C7));
    polygon(canvas,[Offset(hr.left-4,hr.top+2),Offset(h.dx,hr.top-s*.38),Offset(hr.right+4,hr.top+2)],const Color(0xFF9B4F36));
    canvas.drawRect(Rect.fromCenter(center:Offset(h.dx,hr.bottom-s*.12),width:s*.18,height:s*.32),Paint()..color=const Color(0xFF76513A));

    // الحظيرة
    final barn=iso(6.6,.7,c,s);
    final br=Rect.fromCenter(center:Offset(barn.dx,barn.dy-s*.18),width:s*.82,height:s*.52);
    canvas.drawRect(br,Paint()..color=const Color(0xFFB85D45));
    polygon(canvas,[Offset(br.left-4,br.top+2),Offset(barn.dx,br.top-s*.32),Offset(br.right+4,br.top+2)],const Color(0xFF713E32));
    canvas.drawRect(Rect.fromCenter(center:Offset(barn.dx,br.bottom-s*.12),width:s*.22,height:s*.28),Paint()..color=const Color(0xFF754735));

    // أشجار وظلالها
    for(final t in [iso(.3,3,c,s),iso(7.4,4.8,c,s),iso(.8,5,c,s),iso(6.8,2,c,s)]) {
      canvas.drawOval(Rect.fromCenter(center:Offset(t.dx,t.dy+s*.1),width:s*.72,height:s*.25),Paint()..color=const Color(0x33402B1C));
      canvas.drawRect(Rect.fromCenter(center:Offset(t.dx,t.dy-s*.1),width:s*.12,height:s*.5),Paint()..color=const Color(0xFF76523A));
      canvas.drawCircle(Offset(t.dx,t.dy-s*.43),s*.33,Paint()..color=const Color(0xFF397A42));
      canvas.drawCircle(Offset(t.dx-s*.15,t.dy-s*.35),s*.21,Paint()..color=const Color(0xFF4F944B));
    }

    // الجرار القابل للتحريك
    final t=iso(tx,ty,c,s);
    canvas.drawOval(Rect.fromCenter(center:Offset(t.dx,t.dy+s*.17),width:s,height:s*.34),Paint()..color=const Color(0x44000000));
    canvas.drawCircle(Offset(t.dx-s*.22,t.dy+s*.08),s*.18,Paint()..color=const Color(0xFF252A2B));
    canvas.drawCircle(Offset(t.dx+s*.27,t.dy+s*.08),s*.14,Paint()..color=const Color(0xFF252A2B));
    canvas.drawCircle(Offset(t.dx-s*.22,t.dy+s*.08),s*.075,Paint()..color=const Color(0xFFB9C0BD));
    canvas.drawCircle(Offset(t.dx+s*.27,t.dy+s*.08),s*.06,Paint()..color=const Color(0xFFB9C0BD));
    final body=Rect.fromCenter(center:Offset(t.dx,t.dy-s*.03),width:s*.72,height:s*.3);
    canvas.drawRRect(RRect.fromRectAndRadius(body,Radius.circular(s*.06)),Paint()..color=const Color(0xFFE4A92F));
    final cab=Rect.fromCenter(center:Offset(t.dx-s*.04,t.dy-s*.26),width:s*.36,height:s*.42);
    canvas.drawRRect(RRect.fromRectAndRadius(cab,Radius.circular(s*.05)),Paint()..color=const Color(0xFF376B72));
    canvas.drawRRect(RRect.fromRectAndRadius(cab.deflate(s*.045),Radius.circular(s*.04)),Paint()..color=const Color(0xFF9BCBD0));

    final cloud=Paint()..color=Colors.white.withValues(alpha:.82);
    for(final q in [Offset(size.width*.2,size.height*.13),Offset(size.width*.76,size.height*.17)]) {
      canvas.drawCircle(q,9,cloud); canvas.drawCircle(q+const Offset(11,2),12,cloud); canvas.drawCircle(q+const Offset(23,5),8,cloud);
    }
  }

  @override
  bool shouldRepaint(covariant _FarmPainter old) =>
    old.tx!=tx||old.ty!=ty||old.stage!=stage||old.zoom!=zoom;
}
