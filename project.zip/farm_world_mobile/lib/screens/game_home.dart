import 'package:flutter/material.dart';
import '../widgets/farm_world_scene.dart';

class GameHome extends StatefulWidget {
  const GameHome({super.key});

  @override
  State<GameHome> createState() => _GameHomeState();
}

class _GameHomeState extends State<GameHome> {
  int _tab = 0;
  int _coins = 12500;
  int _wheat = 24;
  int _corn = 12;
  double _tractorX = 3.0;
  double _tractorY = 4.0;
  double _sceneZoom = 1.0;
  int _fieldStage = 0; // 0 تربة، 1 مزروع، 2 جاهز للحصاد

  void _sellHarvest() {
    if (_wheat == 0 && _corn == 0) {
      _message('لا توجد محاصيل للبيع حالياً');
      return;
    }
    setState(() {
      _coins += _wheat * 35 + _corn * 52;
      _wheat = 0;
      _corn = 0;
    });
    _message('تم بيع المحاصيل وإضافة الأرباح إلى رصيدك');
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _farmPage(),
      _garagePage(),
      _marketPage(),
      _profilePage(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.agriculture, color: Color(0xFF4D8B45)),
          SizedBox(width: 9),
          Text('عالم المزرعة', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        actions: [
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 14),
            child: Chip(
              avatar: const Icon(Icons.monetization_on, color: Color(0xFFE2A52B)),
              label: Text('$_coins'),
              side: BorderSide.none,
              backgroundColor: const Color(0xFFFFF1D2),
            ),
          ),
        ],
      ),
      body: SafeArea(child: AnimatedSwitcher(duration: const Duration(milliseconds: 220), child: pages[_tab])),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.grass_outlined), selectedIcon: Icon(Icons.grass), label: 'مزرعتي'),
          NavigationDestination(icon: Icon(Icons.agriculture_outlined), selectedIcon: Icon(Icons.agriculture), label: 'المرآب'),
          NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'المتجر'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }

  Widget _farmPage() => ListView(
    key: const ValueKey('farm'),
    padding: const EdgeInsets.all(16),
    children: [
      Row(children: [
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('مزرعتك المفتوحة',style:TextStyle(fontSize:21,fontWeight:FontWeight.w800)),
          SizedBox(height:3),
          Text('تحرّك بالجرار وتفاعل مع أرضك',style:TextStyle(color:Colors.black54)),
        ])),
        _tag('المرحلة 2'),
      ]),
      const SizedBox(height:12),
      FarmWorldScene(tractorX:_tractorX,tractorY:_tractorY,fieldStage:_fieldStage,zoom:_sceneZoom),
      const SizedBox(height:7),
      Row(children:[
        const Icon(Icons.info_outline,size:17,color:Color(0xFF527C45)),
        const SizedBox(width:6),
        Expanded(child:Text(_fieldStage==0?'الحقل جاهز للزراعة':_fieldStage==1?'المحصول ينمو في أرضك':'المحصول جاهز للحصاد',style:const TextStyle(fontSize:12,color:Colors.black54))),
        IconButton(tooltip:'تكبير',onPressed:()=>setState(()=>_sceneZoom=(_sceneZoom+.08).clamp(.82,1.22)),icon:const Icon(Icons.zoom_in)),
        IconButton(tooltip:'تصغير',onPressed:()=>setState(()=>_sceneZoom=(_sceneZoom-.08).clamp(.82,1.22)),icon:const Icon(Icons.zoom_out)),
      ]),
      Card(child:Padding(padding:const EdgeInsets.all(12),child:Row(children:[
        Expanded(child:Column(children:[
          const Text('تحكم بالجرار',style:TextStyle(fontWeight:FontWeight.bold)),
          const SizedBox(height:7),
          _movementButton(Icons.keyboard_arrow_up,-1,0),
          Row(mainAxisAlignment:MainAxisAlignment.center,children:[
            _movementButton(Icons.keyboard_arrow_right,0,1),
            const SizedBox(width:6),
            _movementButton(Icons.keyboard_arrow_down,1,0),
            const SizedBox(width:6),
            _movementButton(Icons.keyboard_arrow_left,0,-1),
          ]),
        ])),
        Container(width:1,height:92,color:Colors.black12),
        const SizedBox(width:12),
        Expanded(child:Column(children:[
          const Icon(Icons.agriculture,color:Color(0xFF4D8B45),size:28),
          const SizedBox(height:5),
          const Text('الجرار الأساسي',style:TextStyle(fontWeight:FontWeight.bold)),
          Text('الموقع: ${_tractorX.toStringAsFixed(0)} ، ${_tractorY.toStringAsFixed(0)}',style:const TextStyle(fontSize:11,color:Colors.black54)),
          TextButton.icon(onPressed:_resetTractor,icon:const Icon(Icons.center_focus_strong,size:16),label:const Text('إعادة')),
        ])),
      ]))),
      const SizedBox(height:12),
      Row(children:[
        Expanded(child:FilledButton.icon(onPressed:_workField,icon:Icon(_fieldStage==0?Icons.agriculture:_fieldStage==1?Icons.water_drop:Icons.grass),label:Text(_fieldStage==0?'ازرع الحقل':_fieldStage==1?'تقدم النمو':'احصد المحصول'))),
        const SizedBox(width:9),
        Expanded(child:OutlinedButton.icon(onPressed:_sellHarvest,icon:const Icon(Icons.sell_outlined),label:const Text('بيع المحاصيل'))),
      ]),
      const SizedBox(height:18),
      const Text('ملخص المزرعة',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
      const SizedBox(height:10),
      Row(children:[
        Expanded(child:_statCard('مساحة الأرض','4 هكتار',Icons.landscape,const Color(0xFFE5F1DE))),
        const SizedBox(width:10),
        Expanded(child:_statCard('المستوى','1',Icons.stars,const Color(0xFFFFF0D2))),
        const SizedBox(width:10),
        Expanded(child:_statCard('العمال','2',Icons.people,const Color(0xFFE1EDFA))),
      ]),
      const SizedBox(height:12),
      const Text('ملاحظة: هذا مشهد إيزومتري تفاعلي شبه ثلاثي الأبعاد (2.5D) مرسوم بـ Flutter، وليس محرك 3D حقيقياً بعد. لم تتم إضافة فيزياء المركبات أو اللعب الجماعي.',style:TextStyle(color:Colors.black54,fontSize:12)),
    ],
  );

  Widget _movementButton(IconData icon,double dx,double dy)=>SizedBox(
    width:42,height:38,
    child:IconButton.filledTonal(
      padding:EdgeInsets.zero,visualDensity:VisualDensity.compact,
      onPressed:()=>_moveTractor(dx,dy),icon:Icon(icon,size:23),
    ),
  );

  void _moveTractor(double dx,double dy){
    setState((){
      _tractorX=(_tractorX+dx).clamp(.4,7.4);
      _tractorY=(_tractorY+dy).clamp(.4,5.4);
    });
  }

  void _resetTractor(){
    setState(() {
      _tractorX = 3;
      _tractorY = 4;
      _sceneZoom = 1;
    });
  }

  void _workField(){
    setState((){
      _fieldStage=(_fieldStage+1)%3;
      if(_fieldStage==2){_wheat+=5;}
    });
    _message(_fieldStage==1?'تمت زراعة الحقل — نمو تجريبي':_fieldStage==2?'المحصول جاهز وأضيفت كمية تجريبية للمخزون':'تم تجهيز الحقل لدورة زراعة جديدة');
  }

  Widget _garagePage() => ListView(
    key: const ValueKey('garage'),
    padding: const EdgeInsets.all(16),
    children: [
      const Text('مرآب الآلات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('إدارة مركبات مزرعتك ومعدّاتك الزراعية'),
      const SizedBox(height: 18),
      _vehicleCard('جرار المزرعة الأساسي', 'متاح', Icons.agriculture, 'السرعة: 18 كم/س'),
      _vehicleCard('محراث', 'ملحق', Icons.construction, 'عرض العمل: 2 متر'),
      _vehicleCard('آلة حصاد', 'مقفلة', Icons.precision_manufacturing, 'تُفتح عند المستوى 3'),
      const SizedBox(height: 12),
      const Text('نماذج تعريفية فقط؛ قيادة المركبات ثلاثية الأبعاد ستضاف في مرحلة محرك اللعبة.', style: TextStyle(color: Colors.black54, fontSize: 12)),
    ],
  );

  Widget _marketPage() => ListView(
    key: const ValueKey('market'),
    padding: const EdgeInsets.all(16),
    children: [
      const Text('سوق المزرعة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('اشترِ البذور والمستلزمات لتطوير إنتاجك'),
      const SizedBox(height: 18),
      _productCard('بذور القمح', '120 قطعة', Icons.grass, () => _buy(120, 'تم شراء بذور القمح')),
      _productCard('بذور الذرة', '180 قطعة', Icons.eco, () => _buy(180, 'تم شراء بذور الذرة')),
      _productCard('سماد عضوي', '250 قطعة', Icons.compost, () => _buy(250, 'تم شراء السماد')),
      _productCard('وقود الجرار', '90 قطعة', Icons.local_gas_station, () => _buy(90, 'تم شراء الوقود')),
    ],
  );

  void _buy(int price, String success) {
    if (_coins < price) {
      _message('رصيدك غير كافٍ');
      return;
    }
    setState(() => _coins -= price);
    _message(success);
  }

  Widget _profilePage() => ListView(
    key: const ValueKey('profile'),
    padding: const EdgeInsets.all(16),
    children: [
      const CircleAvatar(radius: 42, backgroundColor: Color(0xFFDCEBD5), child: Icon(Icons.person, size: 46, color: Color(0xFF4D8B45))),
      const SizedBox(height: 12),
      const Center(child: Text('مزارع جديد', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold))),
      const Center(child: Text('المستوى 1 • مبتدئ', style: TextStyle(color: Colors.black54))),
      const SizedBox(height: 22),
      _settingTile(Icons.cloud_outlined, 'حالة الحفظ', 'محلي على هذا الجهاز', () {}),
      _settingTile(Icons.group_outlined, 'اللعب الجماعي', 'قريباً — لم يتم ربط الخادم', () => _message('سيتم تفعيل اللعب الجماعي في مرحلة لاحقة')),
      _settingTile(Icons.settings_outlined, 'الإعدادات', 'الصوت واللغة والتحكم', () {}),
      _settingTile(Icons.info_outline, 'حول اللعبة', 'Farm World Mobile • إصدار تجريبي', () {}),
    ],
  );

  Widget _tag(String text) => Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .88), borderRadius: BorderRadius.circular(30)), child: Text(text, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF315E3A))));

  Widget _statCard(String title, String value, IconData icon, Color color) => Card(child: Padding(padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8), child: Column(children: [CircleAvatar(backgroundColor: color, child: Icon(icon, color: const Color(0xFF315E3A))), const SizedBox(height: 8), Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), Text(title, style: const TextStyle(fontSize: 11, color: Colors.black54))])));

  Widget _fieldCard(String title, String crop, String status, IconData icon, Color color) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: color.withValues(alpha: .2), child: Icon(icon, color: color)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('$crop • $status'), trailing: const Icon(Icons.chevron_left)));

  Widget _vehicleCard(String title, String status, IconData icon, String detail) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFFE5F1DE), child: Icon(icon, color: const Color(0xFF4D8B45))), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(detail), trailing: Text(status, style: const TextStyle(color: Color(0xFF4D8B45), fontWeight: FontWeight.bold))));

  Widget _productCard(String title, String price, IconData icon, VoidCallback onBuy) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFFFFF0D2), child: Icon(icon, color: const Color(0xFF9A6B16))), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(price), trailing: FilledButton.tonal(onPressed: onBuy, child: const Text('شراء'))));

  Widget _settingTile(IconData icon, String title, String subtitle, VoidCallback onTap) => Card(child: ListTile(onTap: onTap, leading: Icon(icon, color: const Color(0xFF4D8B45)), title: Text(title), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_left)));
}
