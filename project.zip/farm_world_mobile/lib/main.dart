import 'package:flutter/material.dart';
import 'screens/game_home.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FarmWorldApp());
}

class FarmWorldApp extends StatelessWidget {
  const FarmWorldApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF4D8B45);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'عالم المزرعة',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF4F6EF),
        fontFamily: 'Roboto',
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: GameHome(),
      ),
    );
  }
}
