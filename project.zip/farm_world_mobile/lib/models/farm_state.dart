class FarmState {
  const FarmState({
    required this.coins,
    required this.wheat,
    required this.corn,
    required this.level,
  });

  final int coins;
  final int wheat;
  final int corn;
  final int level;

  Map<String, dynamic> toJson() => {
    'coins': coins,
    'wheat': wheat,
    'corn': corn,
    'level': level,
  };

  factory FarmState.fromJson(Map<String, dynamic> json) => FarmState(
    coins: json['coins'] as int? ?? 0,
    wheat: json['wheat'] as int? ?? 0,
    corn: json['corn'] as int? ?? 0,
    level: json['level'] as int? ?? 1,
  );
}
