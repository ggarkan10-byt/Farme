// Firebase connection is intentionally not initialized in the demo build.
// Next setup step: run FlutterFire CLI in a trusted build environment,
// generate firebase_options.dart, then initialize Firebase in main.dart.
// Never commit service-account private keys or admin credentials.
class FirebaseService {
  const FirebaseService._();

  static const bool isConfigured = false;
}
