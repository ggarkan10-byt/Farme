import 'package:flutter_test/flutter_test.dart';
import 'package:farm_world_mobile/main.dart';

void main() {
  testWidgets('shows farm home and navigation', (tester) async {
    await tester.pumpWidget(const FarmWorldApp());
    expect(find.text('عالم المزرعة'), findsOneWidget);
    expect(find.text('مزرعتي'), findsOneWidget);
    expect(find.text('المرآب'), findsOneWidget);
  });
}
